import { Router, type Request, type Response } from 'express';
import { requireAuth } from '../middlewares/auth';
import { storage } from '../db-storage';
import { ReportGenerator } from '../utils/reports';

const router = Router();

router.get('/contas/:format', requireAuth, async (req: Request, res: Response) => {
  try {
    const userId = req.session.userId!;
    const { format } = req.params as { format: 'pdf' | 'excel' };
    const { tipo } = req.query as { tipo?: 'receber' | 'pagar' | 'todas' };

    if (format !== 'pdf' && format !== 'excel') {
      return res.status(400).json({ error: 'Formato inválido' });
    }

    const contas = await storage.getContas(userId);
    const report = await ReportGenerator.generateContasReport(
      contas, 
      format, 
      tipo || 'todas'
    );

    const filename = `contas-${tipo || 'todas'}-${Date.now()}.${format === 'pdf' ? 'pdf' : 'xlsx'}`;
    
    if (format === 'pdf') {
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      (report as NodeJS.ReadableStream).pipe(res);
    } else {
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(report);
    }
  } catch (error) {
    console.error('Erro ao gerar relatório de contas:', error);
    res.status(500).json({ error: 'Erro ao gerar relatório' });
  }
});

router.get('/faturas/:format', requireAuth, async (req: Request, res: Response) => {
  try {
    const userId = req.session.userId!;
    const { format } = req.params as { format: 'pdf' | 'excel' };

    if (format !== 'pdf' && format !== 'excel') {
      return res.status(400).json({ error: 'Formato inválido' });
    }

    const faturas = await storage.getFaturas(userId);
    const report = await ReportGenerator.generateFaturasReport(faturas, format);

    const filename = `faturas-${Date.now()}.${format === 'pdf' ? 'pdf' : 'xlsx'}`;
    
    if (format === 'pdf') {
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      (report as NodeJS.ReadableStream).pipe(res);
    } else {
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(report);
    }
  } catch (error) {
    console.error('Erro ao gerar relatório de faturas:', error);
    res.status(500).json({ error: 'Erro ao gerar relatório' });
  }
});

router.get('/contatos/:format', requireAuth, async (req: Request, res: Response) => {
  try {
    const userId = req.session.userId!;
    const { format } = req.params as { format: 'pdf' | 'excel' };
    const { tipo } = req.query as { tipo?: 'cliente' | 'fornecedor' };

    if (format !== 'pdf' && format !== 'excel') {
      return res.status(400).json({ error: 'Formato inválido' });
    }

    const contatos = await storage.getContatos(userId);
    const report = await ReportGenerator.generateContatosReport(contatos, format, tipo);

    const filename = `contatos-${tipo || 'todos'}-${Date.now()}.${format === 'pdf' ? 'pdf' : 'xlsx'}`;
    
    if (format === 'pdf') {
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      (report as NodeJS.ReadableStream).pipe(res);
    } else {
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(report);
    }
  } catch (error) {
    console.error('Erro ao gerar relatório de contatos:', error);
    res.status(500).json({ error: 'Erro ao gerar relatório' });
  }
});

export default router;
