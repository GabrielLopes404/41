import { db } from './db';
import { 
  users, contas, faturas, contatos, fluxoCaixa, conciliacoes
} from '@shared/schema';
import type { 
  User, InsertUser, UpdateUser,
  Conta, InsertConta, UpdateConta,
  Fatura, InsertFatura, UpdateFatura,
  Contato, InsertContato, UpdateContato,
  FluxoCaixa, InsertFluxoCaixa,
  Conciliacao, InsertConciliacao, UpdateConciliacao,
} from '@shared/schema';
import { eq, and, gte, lte, desc, asc, sql } from 'drizzle-orm';
import type { IStorage } from './storage';
import bcrypt from 'bcryptjs';

export class DBStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const result = await db.insert(users).values({
      username: insertUser.username,
      password: hashedPassword,
      email: insertUser.email,
      fullName: insertUser.fullName,
      role: insertUser.role || 'user',
    }).returning();
    return result[0]!;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async updateUser(id: string, updates: UpdateUser): Promise<User | undefined> {
    if (updates.password) {
      updates.password = await bcrypt.hash(updates.password, 10);
    }
    const result = await db.update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  async deleteUser(id: string): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id)).returning();
    return result.length > 0;
  }

  async updateLastLogin(id: string): Promise<void> {
    await db.update(users)
      .set({ lastLogin: new Date() })
      .where(eq(users.id, id));
  }

  async getContas(userId: string, filters?: any): Promise<Conta[]> {
    let query = db.select().from(contas).where(eq(contas.userId, userId));
    
    const conditions = [eq(contas.userId, userId)];
    if (filters?.tipo) {
      conditions.push(eq(contas.tipo, filters.tipo));
    }
    if (filters?.status) {
      conditions.push(eq(contas.status, filters.status));
    }
    if (filters?.categoria) {
      conditions.push(eq(contas.categoria, filters.categoria));
    }
    
    return await db.select().from(contas)
      .where(and(...conditions))
      .orderBy(desc(contas.dataVencimento));
  }

  async getConta(id: string, userId: string): Promise<Conta | undefined> {
    const result = await db.select().from(contas)
      .where(and(eq(contas.id, id), eq(contas.userId, userId)))
      .limit(1);
    return result[0];
  }

  async createConta(userId: string, insertConta: InsertConta): Promise<Conta> {
    const result = await db.insert(contas).values({
      ...insertConta,
      userId,
      status: insertConta.status || 'pendente',
    }).returning();
    return result[0]!;
  }

  async updateConta(id: string, userId: string, updates: UpdateConta): Promise<Conta | undefined> {
    const result = await db.update(contas)
      .set({ ...updates, updatedAt: new Date() })
      .where(and(eq(contas.id, id), eq(contas.userId, userId)))
      .returning();
    return result[0];
  }

  async deleteConta(id: string, userId: string): Promise<boolean> {
    const result = await db.delete(contas)
      .where(and(eq(contas.id, id), eq(contas.userId, userId)))
      .returning();
    return result.length > 0;
  }

  async getFaturas(userId: string, filters?: any): Promise<Fatura[]> {
    const conditions = [eq(faturas.userId, userId)];
    if (filters?.status) {
      conditions.push(eq(faturas.status, filters.status));
    }
    if (filters?.contatoId) {
      conditions.push(eq(faturas.contatoId, filters.contatoId));
    }
    
    return await db.select().from(faturas)
      .where(and(...conditions))
      .orderBy(desc(faturas.dataEmissao));
  }

  async getFatura(id: string, userId: string): Promise<Fatura | undefined> {
    const result = await db.select().from(faturas)
      .where(and(eq(faturas.id, id), eq(faturas.userId, userId)))
      .limit(1);
    return result[0];
  }

  async createFatura(userId: string, insertFatura: InsertFatura): Promise<Fatura> {
    const result = await db.insert(faturas).values({
      ...insertFatura,
      userId,
      status: insertFatura.status || 'emitida',
    }).returning();
    return result[0]!;
  }

  async updateFatura(id: string, userId: string, updates: UpdateFatura): Promise<Fatura | undefined> {
    const result = await db.update(faturas)
      .set({ ...updates, updatedAt: new Date() })
      .where(and(eq(faturas.id, id), eq(faturas.userId, userId)))
      .returning();
    return result[0];
  }

  async deleteFatura(id: string, userId: string): Promise<boolean> {
    const result = await db.delete(faturas)
      .where(and(eq(faturas.id, id), eq(faturas.userId, userId)))
      .returning();
    return result.length > 0;
  }

  async getContatos(userId: string, filters?: any): Promise<Contato[]> {
    const conditions = [eq(contatos.userId, userId)];
    if (filters?.tipo) {
      conditions.push(eq(contatos.tipo, filters.tipo));
    }
    if (filters?.ativo !== undefined) {
      conditions.push(eq(contatos.ativo, filters.ativo));
    }
    
    return await db.select().from(contatos)
      .where(and(...conditions))
      .orderBy(asc(contatos.nome));
  }

  async getContato(id: string, userId: string): Promise<Contato | undefined> {
    const result = await db.select().from(contatos)
      .where(and(eq(contatos.id, id), eq(contatos.userId, userId)))
      .limit(1);
    return result[0];
  }

  async createContato(userId: string, insertContato: InsertContato): Promise<Contato> {
    const result = await db.insert(contatos).values({
      ...insertContato,
      userId,
      ativo: insertContato.ativo !== undefined ? insertContato.ativo : true,
    }).returning();
    return result[0]!;
  }

  async updateContato(id: string, userId: string, updates: UpdateContato): Promise<Contato | undefined> {
    const result = await db.update(contatos)
      .set({ ...updates, updatedAt: new Date() })
      .where(and(eq(contatos.id, id), eq(contatos.userId, userId)))
      .returning();
    return result[0];
  }

  async deleteContato(id: string, userId: string): Promise<boolean> {
    const result = await db.delete(contatos)
      .where(and(eq(contatos.id, id), eq(contatos.userId, userId)))
      .returning();
    return result.length > 0;
  }

  async getFluxoCaixa(userId: string, dataInicio: Date, dataFim: Date): Promise<FluxoCaixa[]> {
    return await db.select().from(fluxoCaixa)
      .where(
        and(
          eq(fluxoCaixa.userId, userId),
          gte(fluxoCaixa.data, dataInicio),
          lte(fluxoCaixa.data, dataFim)
        )
      )
      .orderBy(asc(fluxoCaixa.data));
  }

  async createFluxoCaixa(userId: string, insertFluxo: InsertFluxoCaixa): Promise<FluxoCaixa> {
    const result = await db.insert(fluxoCaixa).values({
      ...insertFluxo,
      userId,
    }).returning();
    return result[0]!;
  }

  async getConciliacoes(userId: string): Promise<Conciliacao[]> {
    return await db.select().from(conciliacoes)
      .where(eq(conciliacoes.userId, userId))
      .orderBy(desc(conciliacoes.dataInicio));
  }

  async getConciliacao(id: string, userId: string): Promise<Conciliacao | undefined> {
    const result = await db.select().from(conciliacoes)
      .where(and(eq(conciliacoes.id, id), eq(conciliacoes.userId, userId)))
      .limit(1);
    return result[0];
  }

  async createConciliacao(userId: string, insertConciliacao: InsertConciliacao): Promise<Conciliacao> {
    const result = await db.insert(conciliacoes).values({
      ...insertConciliacao,
      userId,
      status: insertConciliacao.status || 'em_progresso',
    }).returning();
    return result[0]!;
  }

  async updateConciliacao(id: string, userId: string, updates: UpdateConciliacao): Promise<Conciliacao | undefined> {
    const result = await db.update(conciliacoes)
      .set({ ...updates, updatedAt: new Date() })
      .where(and(eq(conciliacoes.id, id), eq(conciliacoes.userId, userId)))
      .returning();
    return result[0];
  }

  async deleteConciliacao(id: string, userId: string): Promise<boolean> {
    const result = await db.delete(conciliacoes)
      .where(and(eq(conciliacoes.id, id), eq(conciliacoes.userId, userId)))
      .returning();
    return result.length > 0;
  }

  async getDashboardStats(userId: string): Promise<any> {
    const now = new Date();
    const mesAtual = new Date(now.getFullYear(), now.getMonth(), 1);
    const proximoMes = new Date(now.getFullYear(), now.getMonth() + 1, 1);

    const contasReceber = await db.select().from(contas)
      .where(
        and(
          eq(contas.userId, userId),
          eq(contas.tipo, 'receber'),
          gte(contas.dataVencimento, mesAtual),
          lte(contas.dataVencimento, proximoMes)
        )
      );
    
    const contasPagar = await db.select().from(contas)
      .where(
        and(
          eq(contas.userId, userId),
          eq(contas.tipo, 'pagar'),
          gte(contas.dataVencimento, mesAtual),
          lte(contas.dataVencimento, proximoMes)
        )
      );

    const contasVencidasResult = await db.select({ count: sql<number>`count(*)` }).from(contas)
      .where(
        and(
          eq(contas.userId, userId),
          eq(contas.status, 'pendente'),
          lte(contas.dataVencimento, now)
        )
      );

    const faturasEmitidasResult = await db.select({ count: sql<number>`count(*)` }).from(faturas)
      .where(
        and(
          eq(faturas.userId, userId),
          eq(faturas.status, 'emitida')
        )
      );

    const totalContatos = await db.select({ count: sql<number>`count(*)` }).from(contatos)
      .where(eq(contatos.userId, userId));

    const totalContasResult = await db.select({ count: sql<number>`count(*)` }).from(contas)
      .where(eq(contas.userId, userId));

    const totalFaturasResult = await db.select({ count: sql<number>`count(*)` }).from(faturas)
      .where(eq(faturas.userId, userId));

    const receberMes = contasReceber.reduce((sum, c) => sum + parseFloat(c.valor), 0);
    const pagarMes = contasPagar.reduce((sum, c) => sum + parseFloat(c.valor), 0);

    return {
      totalReceberMes: receberMes,
      totalPagarMes: pagarMes,
      saldoProjetado: receberMes - pagarMes,
      contasVencidas: Number(contasVencidasResult[0]?.count || 0),
      faturasEmitidas: Number(faturasEmitidasResult[0]?.count || 0),
      totalContatos: Number(totalContatos[0]?.count || 0),
      totalContas: Number(totalContasResult[0]?.count || 0),
      totalFaturas: Number(totalFaturasResult[0]?.count || 0),
    };
  }
}

export const storage = new DBStorage();
