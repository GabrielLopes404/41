# 📘 Guia Completo de Deploy - Sistema Lucrei

Este guia fornece instruções passo a passo para fazer o deploy do sistema Lucrei em diferentes plataformas de hospedagem gratuitas.

## 📋 Índice

1. [Preparação Inicial](#preparação-inicial)
2. [Deploy no Render.com](#1-rendercom-recomendado)
3. [Deploy no Railway.app](#2-railwayapp)
4. [Deploy no Google Cloud](#3-google-cloud-app-engine)
5. [Deploy no Fly.io](#4-flyio)
6. [Deploy no Vercel (apenas frontend)](#5-vercel-apenas-frontend)
7. [Configurações Pós-Deploy](#configurações-pós-deploy)

---

## Preparação Inicial

### Passo 1: Gerar Chaves de Segurança

Antes de fazer deploy, você precisa gerar chaves de segurança únicas. Execute este comando no terminal:

```bash
node -e "console.log('ACCESS_TOKEN_SECRET:', require('crypto').randomBytes(32).toString('hex')); console.log('REFRESH_TOKEN_SECRET:', require('crypto').randomBytes(32).toString('hex')); console.log('SESSION_SECRET:', require('crypto').randomBytes(32).toString('hex')); console.log('ENCRYPTION_KEY:', require('crypto').randomBytes(32).toString('hex').substring(0, 32));"
```

**Guarde estas chaves em local seguro!** Você precisará delas para configurar as variáveis de ambiente.

### Passo 2: Preparar o Repositório

1. Certifique-se de que seu código está no GitHub:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/SEU-USUARIO/SEU-REPO.git
   git push -u origin main
   ```

---

## 1. Render.com (RECOMENDADO) 🌟

**Por que escolher?** Plano gratuito generoso, fácil de usar, suporta PostgreSQL gratuito.

### Passo a Passo:

1. **Criar conta** em [render.com](https://render.com)

2. **Conectar o GitHub:**
   - Clique em "New +" → "Web Service"
   - Conecte sua conta GitHub
   - Selecione seu repositório

3. **Configurar o serviço:**
   - **Name:** `lucrei-finance` (ou o nome que preferir)
   - **Region:** Oregon (US West)
   - **Branch:** `main`
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`
   - **Plan:** Free

4. **Configurar variáveis de ambiente:**
   
   Clique em "Environment" e adicione:
   
   ```
   NODE_ENV=production
   PORT=5000
   ACCESS_TOKEN_SECRET=sua_chave_gerada_aqui
   REFRESH_TOKEN_SECRET=sua_chave_gerada_aqui
   SESSION_SECRET=sua_chave_gerada_aqui
   ENCRYPTION_KEY=sua_chave_32_caracteres_aqui
   ```

5. **Adicionar banco de dados PostgreSQL (opcional):**
   - Clique em "New +" → "PostgreSQL"
   - Name: `lucrei-db`
   - Plan: Free
   - Copie a "Internal Database URL"
   - Adicione como variável: `DATABASE_URL=url_copiada`

6. **Deploy:**
   - Clique em "Create Web Service"
   - Aguarde o build (3-5 minutos)
   - Acesse sua URL: `https://lucrei-finance.onrender.com`

### ⚠️ Importante:
- Plano gratuito "dorme" após 15min de inatividade
- Primeiro acesso após inatividade pode demorar ~30s

---

## 2. Railway.app

**Por que escolher?** Interface moderna, deploys rápidos, $5 de crédito grátis por mês.

### Passo a Passo:

1. **Criar conta** em [railway.app](https://railway.app)

2. **Novo projeto:**
   - Clique em "New Project"
   - Selecione "Deploy from GitHub repo"
   - Conecte e selecione seu repositório

3. **Configurações automáticas:**
   - Railway detecta automaticamente que é Node.js
   - Build e start commands são configurados automaticamente

4. **Variáveis de ambiente:**
   - Clique na aba "Variables"
   - Adicione todas as variáveis de segurança:
   
   ```
   NODE_ENV=production
   ACCESS_TOKEN_SECRET=sua_chave_aqui
   REFRESH_TOKEN_SECRET=sua_chave_aqui
   SESSION_SECRET=sua_chave_aqui
   ENCRYPTION_KEY=sua_chave_aqui
   ```

5. **Adicionar PostgreSQL:**
   - Clique em "New" → "Database" → "Add PostgreSQL"
   - Railway conecta automaticamente
   - Variável `DATABASE_URL` é criada automaticamente

6. **Deploy:**
   - Deploy inicia automaticamente
   - Acesse em "Settings" → "Generate Domain"

### 💰 Custos:
- $5/mês grátis (suficiente para testes)
- Execução ilimitada (não "dorme")

---

## 3. Google Cloud App Engine

**Por que escolher?** Infraestrutura do Google, escalável, 28 horas grátis por dia.

### Passo a Passo:

1. **Criar conta Google Cloud:**
   - Acesse [cloud.google.com](https://cloud.google.com)
   - $300 de créditos grátis por 90 dias

2. **Instalar Google Cloud SDK:**
   ```bash
   # Windows
   # Baixe de: https://cloud.google.com/sdk/docs/install
   
   # Mac
   brew install --cask google-cloud-sdk
   
   # Linux
   curl https://sdk.cloud.google.com | bash
   ```

3. **Fazer login e criar projeto:**
   ```bash
   gcloud auth login
   gcloud projects create lucrei-finance --set-as-default
   gcloud app create --region=us-central
   ```

4. **Configurar variáveis de ambiente:**
   
   Edite o arquivo `app.yaml` (já incluído no projeto) e adicione:
   
   ```yaml
   env_variables:
     NODE_ENV: "production"
     PORT: "8080"
     ACCESS_TOKEN_SECRET: "sua_chave_aqui"
     REFRESH_TOKEN_SECRET: "sua_chave_aqui"
     SESSION_SECRET: "sua_chave_aqui"
     ENCRYPTION_KEY: "sua_chave_aqui"
   ```

5. **Deploy:**
   ```bash
   gcloud app deploy
   ```

6. **Acessar aplicação:**
   ```bash
   gcloud app browse
   ```

### 💰 Custos:
- 28 horas de instância F1 grátis por dia
- Suficiente para baixo tráfego

---

## 4. Fly.io

**Por que escolher?** Permite 3 VMs gratuitas, rápido globalmente.

### Passo a Passo:

1. **Criar conta** em [fly.io](https://fly.io)

2. **Instalar flyctl:**
   ```bash
   # Mac/Linux
   curl -L https://fly.io/install.sh | sh
   
   # Windows
   iwr https://fly.io/install.ps1 -useb | iex
   ```

3. **Login:**
   ```bash
   flyctl auth login
   ```

4. **Inicializar app:**
   ```bash
   flyctl launch
   ```
   
   - Nome: `lucrei-finance`
   - Região: São Paulo (gru) ou Miami (mia)
   - PostgreSQL: Sim (se quiser)

5. **Configurar secrets:**
   ```bash
   flyctl secrets set ACCESS_TOKEN_SECRET="sua_chave" \
     REFRESH_TOKEN_SECRET="sua_chave" \
     SESSION_SECRET="sua_chave" \
     ENCRYPTION_KEY="sua_chave" \
     NODE_ENV="production"
   ```

6. **Deploy:**
   ```bash
   flyctl deploy
   ```

7. **Abrir aplicação:**
   ```bash
   flyctl open
   ```

### 💰 Custos:
- 3 máquinas compartilhadas grátis
- 3GB de armazenamento grátis

---

## 5. Vercel (Apenas Frontend)

**Nota:** Vercel é ideal para sites estáticos. Para este projeto full-stack, você precisará separar frontend e backend.

### Opção A: Frontend + Backend Separados

**Frontend (Vercel):**
1. Mova arquivos do `client/` para raiz
2. Configure build: `npm run build`
3. Output directory: `dist`

**Backend (Render/Railway):**
1. Deploy apenas o backend em outra plataforma
2. Configure CORS para aceitar requests do Vercel

### Opção B: Use outra plataforma

Para este projeto full-stack, **recomendo usar Render ou Railway** que suportam aplicações completas.

---

## Configurações Pós-Deploy

### 1. Configurar Domínio Customizado (Opcional)

**Render:**
- Settings → Custom Domain → Adicionar domínio

**Railway:**
- Settings → Public Networking → Custom Domain

**Google Cloud:**
```bash
gcloud app domain-mappings create "seu-dominio.com"
```

### 2. Configurar HTTPS

Todas as plataformas mencionadas fornecem HTTPS gratuito automaticamente via Let's Encrypt.

### 3. Configurar Banco de Dados PostgreSQL

Se não configurou durante o deploy:

**Render:**
- New + → PostgreSQL → Free
- Copie "Internal Database URL"
- Adicione como variável `DATABASE_URL`

**Railway:**
- New → Database → Add PostgreSQL
- Conecta automaticamente

**Google Cloud:**
```bash
gcloud sql instances create lucrei-db --tier=db-f1-micro --region=us-central1
```

### 4. Executar Migrações (se usar banco de dados)

```bash
# Render/Railway - no dashboard, execute:
npm run db:push

# Google Cloud
gcloud run jobs create db-migrate \
  --image gcr.io/seu-projeto/lucrei:latest \
  --command "npm run db:push"
```

---

## 🔐 Checklist de Segurança

Antes de ir para produção:

- [ ] Todas as chaves de segurança geradas são únicas e seguras
- [ ] Variáveis de ambiente configuradas corretamente
- [ ] `NODE_ENV=production` está definido
- [ ] HTTPS está ativado (automático nas plataformas)
- [ ] Backup automático configurado
- [ ] Credenciais de admin padrão foram alteradas

---

## 🐛 Troubleshooting

### Erro: "Application failed to start"
- Verifique os logs da plataforma
- Confirme que todas as variáveis de ambiente estão configuradas
- Verifique se o PORT está correto (5000 ou 8080 dependendo da plataforma)

### Erro: "Database connection failed"
- Verifique se DATABASE_URL está configurada
- Teste conexão com banco de dados
- Verifique credenciais

### Erro: "Build failed"
- Verifique se todas as dependências estão no package.json
- Confirme que build command está correto
- Verifique logs de build

---

## 📊 Comparação de Plataformas

| Plataforma | Plano Gratuito | Dormência | PostgreSQL | Facilidade | Recomendação |
|------------|---------------|-----------|------------|------------|--------------|
| **Render** | ✅ Sim | ⚠️ 15min | ✅ Grátis | ⭐⭐⭐⭐⭐ | **Melhor para iniciantes** |
| **Railway** | 💰 $5/mês | ❌ Não | ✅ Grátis | ⭐⭐⭐⭐ | **Melhor para produção** |
| **Google Cloud** | ✅ 28h/dia | ❌ Não | 💰 Pago | ⭐⭐⭐ | **Melhor para escala** |
| **Fly.io** | ✅ 3 VMs | ❌ Não | ✅ 3GB grátis | ⭐⭐⭐⭐ | **Melhor para global** |
| **Vercel** | ✅ Sim | ❌ Não | ❌ Não | ⭐⭐⭐ | **Apenas frontend** |

---

## 🎯 Recomendação Final

Para começar: **Render.com**
- Fácil de usar
- PostgreSQL gratuito incluído
- Deploy em minutos

Para produção séria: **Railway.app**
- Não dorme
- Execução confiável
- $5/mês é muito acessível

Para grande escala: **Google Cloud**
- Infraestrutura profissional
- Escalabilidade infinita
- Suporte empresarial

---

## 📞 Suporte

Se encontrar problemas:

1. Verifique os logs da plataforma
2. Consulte a documentação oficial
3. Revise o arquivo SECURITY.md para melhores práticas

**Documentações Oficiais:**
- [Render Docs](https://render.com/docs)
- [Railway Docs](https://docs.railway.app)
- [Google Cloud Docs](https://cloud.google.com/appengine/docs)
- [Fly.io Docs](https://fly.io/docs)

---

Feito com ❤️ para facilitar seu deploy!
