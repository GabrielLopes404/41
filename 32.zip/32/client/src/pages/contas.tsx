import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { EmptyState } from "@/components/empty-state";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Plus, 
  Search, 
  MoreHorizontal,
  Edit,
  Trash,
  CheckCircle2,
  Filter,
  Receipt,
  TrendingUp,
  TrendingDown
} from "lucide-react";
import { StatusBadge } from "@/components/status-badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const mockContas = [
  {
    id: 1,
    descricao: "Pagamento Fornecedor ABC",
    categoria: "Fornecedores",
    valor: -5200.00,
    vencimento: "2024-11-15",
    status: "pendente" as const,
    tipo: "pagar"
  },
  {
    id: 2,
    descricao: "Recebimento Cliente XYZ",
    categoria: "Vendas",
    valor: 8900.00,
    vencimento: "2024-11-10",
    status: "pago" as const,
    tipo: "receber"
  },
  {
    id: 3,
    descricao: "Aluguel Escritório",
    categoria: "Despesas Fixas",
    valor: -4200.00,
    vencimento: "2024-11-05",
    status: "pago" as const,
    tipo: "pagar"
  },
  {
    id: 4,
    descricao: "Serviço Consultoria DEF",
    categoria: "Serviços",
    valor: 3500.00,
    vencimento: "2024-11-20",
    status: "agendado" as const,
    tipo: "receber"
  },
  {
    id: 5,
    descricao: "Fornecimento Materiais",
    categoria: "Fornecedores",
    valor: -2800.00,
    vencimento: "2024-11-08",
    status: "vencido" as const,
    tipo: "pagar"
  },
];

const categories = [
  { name: "Recebimentos", count: 2, color: "bg-success/10 text-success border-success/20", gradient: "from-success to-emerald-500" },
  { name: "Despesas fixas", count: 1, color: "bg-destructive/10 text-destructive border-destructive/20", gradient: "from-destructive to-red-500" },
  { name: "Despesas variáveis", count: 2, color: "bg-warning/10 text-warning border-warning/20", gradient: "from-amber-500 to-orange-500" },
  { name: "Pessoas", count: 0, color: "bg-primary/10 text-primary border-primary/20", gradient: "from-primary to-chart-2" },
  { name: "Impostos", count: 0, color: "bg-chart-4/10 text-chart-4 border-chart-4/20", gradient: "from-purple-500 to-pink-500" },
];

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4 }
};

export default function Contas() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterTipo, setFilterTipo] = useState<string>("all");
  const [selectedMonth, setSelectedMonth] = useState("NOV/2025");

  const filteredContas = mockContas.filter(conta => {
    const matchesSearch = conta.descricao.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || conta.status === filterStatus;
    const matchesTipo = filterTipo === "all" || conta.tipo === filterTipo;
    return matchesSearch && matchesStatus && matchesTipo;
  });

  const totals = {
    recebido: mockContas.filter(c => c.valor > 0 && c.status === 'pago').reduce((sum, c) => sum + c.valor, 0),
    aReceber: mockContas.filter(c => c.valor > 0 && c.status !== 'pago').reduce((sum, c) => sum + c.valor, 0),
    pago: mockContas.filter(c => c.valor < 0 && c.status === 'pago').reduce((sum, c) => sum + Math.abs(c.valor), 0),
    aPagar: mockContas.filter(c => c.valor < 0 && c.status !== 'pago').reduce((sum, c) => sum + Math.abs(c.valor), 0),
  };

  return (
    <div className="flex-1 space-y-6 p-6">
      {/* Header */}
      <motion.div 
        className="flex items-center justify-between"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
            Transações
          </h1>
          <p className="text-muted-foreground">Gerencie contas a pagar e receber</p>
        </div>
        <div className="flex gap-2">
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button variant="outline" data-testid="button-filter">
              <Filter className="h-4 w-4 mr-2" />
              Filtrar
            </Button>
          </motion.div>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button data-testid="button-new-transaction" className="bg-gradient-to-r from-primary to-chart-2">
              <Plus className="h-4 w-4 mr-2" />
              Nova Transação
            </Button>
          </motion.div>
        </div>
      </motion.div>

      {/* Resumo */}
      <motion.div {...fadeInUp}>
        <Card className="relative overflow-hidden border-2 hover:border-primary/30 transition-colors">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-chart-2/5 opacity-50" />
          <CardHeader className="pb-3 relative z-10">
            <CardTitle className="text-base flex items-center gap-2">
              <Receipt className="h-5 w-5 text-primary" />
              Resultado previsto no mês
            </CardTitle>
          </CardHeader>
          <CardContent className="relative z-10">
            <motion.div 
              className="text-4xl font-bold font-mono mb-6 bg-gradient-to-r from-success to-emerald-600 bg-clip-text text-transparent"
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              R$ 1,00
            </motion.div>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 rounded-lg hover:bg-success/5 transition-colors">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-success" />
                    <span className="text-sm font-medium text-muted-foreground">Recebido</span>
                  </div>
                  <span className="font-bold font-mono text-lg text-success">
                    R$ {totals.recebido.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                  <motion.div 
                    className="bg-gradient-to-r from-success to-emerald-500 h-3 rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: '100%' }}
                    transition={{ duration: 1, delay: 0.3 }}
                  />
                </div>
                <div className="flex items-center justify-between text-xs px-3">
                  <span className="text-muted-foreground">Previsto</span>
                  <span className="font-mono font-semibold">R$ 80,00</span>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 rounded-lg hover:bg-destructive/5 transition-colors">
                  <div className="flex items-center gap-2">
                    <TrendingDown className="h-4 w-4 text-destructive" />
                    <span className="text-sm font-medium text-muted-foreground">Pago</span>
                  </div>
                  <span className="font-bold font-mono text-lg text-destructive">
                    R$ {totals.pago.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                  <motion.div 
                    className="bg-gradient-to-r from-destructive to-red-500 h-3 rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: '100%' }}
                    transition={{ duration: 1, delay: 0.4 }}
                  />
                </div>
                <div className="flex items-center justify-between text-xs px-3">
                  <span className="text-muted-foreground">Previsto</span>
                  <span className="font-mono font-semibold">R$ 80,00</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Filtros de Categoria */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
          <Button
            variant="default"
            size="sm"
            className="flex-shrink-0 bg-gradient-to-r from-primary to-chart-2"
            data-testid="filter-all-categories"
          >
            Todos
          </Button>
        </motion.div>
        {categories.map((cat, i) => (
          <motion.div 
            key={cat.name}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
          >
            <Badge
              variant="outline"
              className={`${cat.color} flex-shrink-0 cursor-pointer px-4 py-2 font-medium`}
              data-testid={`filter-category-${cat.name.toLowerCase()}`}
            >
              {cat.name} ({cat.count})
            </Badge>
          </motion.div>
        ))}
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card className="border-2 hover:border-primary/30 transition-colors">
          <CardHeader>
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="sm" data-testid="button-prev-month">
                  ‹
                </Button>
                <Badge variant="default" className="font-mono bg-gradient-to-r from-primary to-chart-2">
                  {selectedMonth}
                </Badge>
                <Button variant="ghost" size="sm" data-testid="button-next-month">
                  ›
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                <div className="relative flex-1 min-w-[200px]">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Pesquisar transações..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9"
                    data-testid="input-search-transactions"
                  />
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Descrição</TableHead>
                  <TableHead>Recebido de</TableHead>
                  <TableHead>Categoria</TableHead>
                  <TableHead className="text-right">Valor</TableHead>
                  <TableHead>Tipo pagamento</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredContas.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8}>
                      <EmptyState
                        icon={Plus}
                        title="Nenhuma transação encontrada"
                        description="Comece adicionando sua primeira transação para começar a gerenciar suas finanças"
                        action={{
                          label: "Nova Transação",
                          onClick: () => {}
                        }}
                        gradient="from-primary to-chart-2"
                      />
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredContas.map((conta, index) => (
                    <motion.tr 
                      key={conta.id} 
                      data-testid={`transaction-row-${conta.id}`}
                      className="hover:bg-muted/50 transition-colors"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      whileHover={{ scale: 1.01 }}
                    >
                      <TableCell className="font-mono text-sm">
                        {new Date(conta.vencimento).toLocaleDateString('pt-BR')}
                      </TableCell>
                      <TableCell className="font-medium">{conta.descricao}</TableCell>
                      <TableCell className="text-muted-foreground">-</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="font-medium">{conta.categoria}</Badge>
                      </TableCell>
                      <TableCell className={`text-right font-mono font-bold text-lg ${
                        conta.valor > 0 ? 'text-success' : 'text-destructive'
                      }`}>
                        {conta.valor > 0 ? '+' : ''}R$ {Math.abs(conta.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell className="text-muted-foreground">-</TableCell>
                      <TableCell>
                        <StatusBadge status={conta.status} />
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" data-testid={`button-actions-${conta.id}`}>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem data-testid={`button-mark-paid-${conta.id}`}>
                              <CheckCircle2 className="h-4 w-4 mr-2" />
                              Marcar como Pago
                            </DropdownMenuItem>
                            <DropdownMenuItem data-testid={`button-edit-${conta.id}`}>
                              <Edit className="h-4 w-4 mr-2" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-destructive" data-testid={`button-delete-${conta.id}`}>
                              <Trash className="h-4 w-4 mr-2" />
                              Excluir
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </motion.tr>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
